
# Introduction to NumPy


```python
"""
Drawing the Mandelbrot set
based on R code by Myles Harrison
http://www.everydayanalytics.ca
"""
```




    '\nDrawing the Mandelbrot set\nbased on R code by Myles Harrison\nhttp://www.everydayanalytics.ca\n'




```python
import numpy as np
#from scipy.misc import imshow
import matplotlib.pyplot as plt
from matplotlib.pyplot import imshow
```


```python
SIZE = 50
```


```python
# Like range(), but returns evenly spaced numbers over a specified interval.
x = np.linspace(-2, 1, SIZE)
y = np.linspace(-1.5, 1.5, SIZE)
```


```python
x
```




    array([-2.        , -1.93877551, -1.87755102, -1.81632653, -1.75510204,
           -1.69387755, -1.63265306, -1.57142857, -1.51020408, -1.44897959,
           -1.3877551 , -1.32653061, -1.26530612, -1.20408163, -1.14285714,
           -1.08163265, -1.02040816, -0.95918367, -0.89795918, -0.83673469,
           -0.7755102 , -0.71428571, -0.65306122, -0.59183673, -0.53061224,
           -0.46938776, -0.40816327, -0.34693878, -0.28571429, -0.2244898 ,
           -0.16326531, -0.10204082, -0.04081633,  0.02040816,  0.08163265,
            0.14285714,  0.20408163,  0.26530612,  0.32653061,  0.3877551 ,
            0.44897959,  0.51020408,  0.57142857,  0.63265306,  0.69387755,
            0.75510204,  0.81632653,  0.87755102,  0.93877551,  1.        ])




```python
y
```




    array([-1.5       , -1.43877551, -1.37755102, -1.31632653, -1.25510204,
           -1.19387755, -1.13265306, -1.07142857, -1.01020408, -0.94897959,
           -0.8877551 , -0.82653061, -0.76530612, -0.70408163, -0.64285714,
           -0.58163265, -0.52040816, -0.45918367, -0.39795918, -0.33673469,
           -0.2755102 , -0.21428571, -0.15306122, -0.09183673, -0.03061224,
            0.03061224,  0.09183673,  0.15306122,  0.21428571,  0.2755102 ,
            0.33673469,  0.39795918,  0.45918367,  0.52040816,  0.58163265,
            0.64285714,  0.70408163,  0.76530612,  0.82653061,  0.8877551 ,
            0.94897959,  1.01020408,  1.07142857,  1.13265306,  1.19387755,
            1.25510204,  1.31632653,  1.37755102,  1.43877551,  1.5       ])




```python
# Return a new array of given shape and type, filled with ones.
ones = np.ones(SIZE)
ones
```




    array([1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
           1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
           1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.])




```python
# Compute the outer product of two vectors.
c = np.outer(x, ones) + 1j * np.outer(ones, y)
c
```




    array([[-2.        -1.5j       , -2.        -1.43877551j,
            -2.        -1.37755102j, ..., -2.        +1.37755102j,
            -2.        +1.43877551j, -2.        +1.5j       ],
           [-1.93877551-1.5j       , -1.93877551-1.43877551j,
            -1.93877551-1.37755102j, ..., -1.93877551+1.37755102j,
            -1.93877551+1.43877551j, -1.93877551+1.5j       ],
           [-1.87755102-1.5j       , -1.87755102-1.43877551j,
            -1.87755102-1.37755102j, ..., -1.87755102+1.37755102j,
            -1.87755102+1.43877551j, -1.87755102+1.5j       ],
           ...,
           [ 0.87755102-1.5j       ,  0.87755102-1.43877551j,
             0.87755102-1.37755102j, ...,  0.87755102+1.37755102j,
             0.87755102+1.43877551j,  0.87755102+1.5j       ],
           [ 0.93877551-1.5j       ,  0.93877551-1.43877551j,
             0.93877551-1.37755102j, ...,  0.93877551+1.37755102j,
             0.93877551+1.43877551j,  0.93877551+1.5j       ],
           [ 1.        -1.5j       ,  1.        -1.43877551j,
             1.        -1.37755102j, ...,  1.        +1.37755102j,
             1.        +1.43877551j,  1.        +1.5j       ]])




```python
#Return a new array of given shape and type, filled with zeros.
z = np.zeros((SIZE, SIZE)) * 1j
k = np.zeros((SIZE, SIZE))
```


```python
z
```




    array([[0.+0.j, 0.+0.j, 0.+0.j, ..., 0.+0.j, 0.+0.j, 0.+0.j],
           [0.+0.j, 0.+0.j, 0.+0.j, ..., 0.+0.j, 0.+0.j, 0.+0.j],
           [0.+0.j, 0.+0.j, 0.+0.j, ..., 0.+0.j, 0.+0.j, 0.+0.j],
           ...,
           [0.+0.j, 0.+0.j, 0.+0.j, ..., 0.+0.j, 0.+0.j, 0.+0.j],
           [0.+0.j, 0.+0.j, 0.+0.j, ..., 0.+0.j, 0.+0.j, 0.+0.j],
           [0.+0.j, 0.+0.j, 0.+0.j, ..., 0.+0.j, 0.+0.j, 0.+0.j]])




```python
k
```




    array([[0., 0., 0., ..., 0., 0., 0.],
           [0., 0., 0., ..., 0., 0., 0.],
           [0., 0., 0., ..., 0., 0., 0.],
           ...,
           [0., 0., 0., ..., 0., 0., 0.],
           [0., 0., 0., ..., 0., 0., 0.],
           [0., 0., 0., ..., 0., 0., 0.]])




```python
for i in range(100):
    index = z < 2
    z[index] = z[index] ** 2 + c[index]
    k[index] = k[index] + 1
```

    /home/manohar/anaconda3/lib/python3.7/site-packages/ipykernel_launcher.py:3: RuntimeWarning: overflow encountered in square
      This is separate from the ipykernel package so we can avoid doing imports until
    /home/manohar/anaconda3/lib/python3.7/site-packages/ipykernel_launcher.py:3: RuntimeWarning: invalid value encountered in square
      This is separate from the ipykernel package so we can avoid doing imports until



```python
# Display an image on the axes.
imshow(k)
```




    <matplotlib.image.AxesImage at 0x7faa5e036d68>




![png](output_13_1.png)


# Creating Arrays


```python
# Create an array from scratch
a = np.array([1,1, 2, 2, 3, 3])
a
```




    array([1, 1, 2, 2, 3, 3])




```python
# Two dimensions, also specifying data type:
b = np.array([[1,1], [2, 2], [3, 3]], dtype=np.float64)
b
```




    array([[1., 1.],
           [2., 2.],
           [3., 3.]])




```python
# Create an array with sequential numbers
np.arange(10)
```




    array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])




```python
# Create an array by linear interpolation
np.linspace(1, 4, 7)
```




    array([1. , 1.5, 2. , 2.5, 3. , 3.5, 4. ])




```python
# Create a null vector
np.zeros(10)
```




    array([0., 0., 0., 0., 0., 0., 0., 0., 0., 0.])




```python
# Create a two-dimensional vector
np.ones((3, 3))
```




    array([[1., 1., 1.],
           [1., 1., 1.],
           [1., 1., 1.]])




```python
# Create an identity matrix
np.eye(3)
```




    array([[1., 0., 0.],
           [0., 1., 0.],
           [0., 0., 1.]])




```python
# Create random arrays
np.random.random((3,3))
np.random.normal(0.0, 1.0, 100)
```




    array([-1.392049  , -3.1639351 , -1.06846331,  0.49477467, -0.60308843,
           -0.56346684, -0.84131744, -0.33922819,  1.79878227,  0.28615028,
           -0.20085694, -0.69512135,  0.98119447, -0.55578146,  0.84612947,
           -1.78990465,  0.39842649, -0.24525667, -0.17206938,  0.97010631,
            0.44911646, -0.19165164, -1.0696301 ,  1.6509296 , -0.05196466,
            1.2778401 , -1.12052549,  0.35059333, -0.10405464,  0.61465169,
            0.87102403, -0.27233597,  0.52903593,  0.41844558,  0.90635073,
            0.75374108,  0.34069089, -1.62913566,  0.84426148,  0.31951461,
            0.76357093,  1.31197791, -0.99962697, -2.23260689,  0.91594584,
           -0.35440994,  0.16078056,  0.67348605,  0.29225578,  1.38671009,
            0.22568746,  0.66985684, -1.22971645, -0.63203237, -0.18508396,
            0.50312564, -0.05642033,  1.85989311,  0.2613033 , -0.69573911,
           -1.38542212, -0.0829887 ,  0.49953115,  0.05233531, -1.15242115,
            0.45143593,  0.74642378,  0.9046081 ,  0.04335098, -0.08228686,
           -0.09213058,  1.35846541,  0.90262789, -1.48370849,  1.07908181,
            0.70764541, -1.84952212,  0.40425417,  0.23423923,  2.23545003,
           -0.09449289, -0.43721443,  1.18640807,  0.42135637, -0.22199005,
            0.0583222 ,  0.35301181, -1.32562381, -0.0160559 ,  0.27075026,
           -1.26738628,  1.45588943, -0.53537656,  0.81707389,  0.57220039,
           -1.05437239,  0.3341369 ,  1.49196837,  1.30374535, -1.01428359])




```python
# Create x/y gradients
np.meshgrid([0, 1, 2], [0, 1, 2])
```




    [array([[0, 1, 2],
            [0, 1, 2],
            [0, 1, 2]]), array([[0, 0, 0],
            [1, 1, 1],
            [2, 2, 2]])]



# Selecting and modifying arrays


```python
# Replace values in an array
a = np.zeros(10)
a[4] = 1
a
```




    array([0., 0., 0., 0., 1., 0., 0., 0., 0., 0.])




```python
# Reverse a vector
a = np.arange(10)
a[::-1]
```




    array([9, 8, 7, 6, 5, 4, 3, 2, 1, 0])




```python
# Change the shape of arrays
np.arange(9).reshape(3,3)
```




    array([[0, 1, 2],
           [3, 4, 5],
           [6, 7, 8]])




```python
# Find indices of non-zero elements
np.nonzero([1, 2, 0, 0, 4, 0])
```




    (array([0, 1, 4]),)




```python
# Apply mathematical functions
a = np.arange(5)
np.exp(a)
```




    array([ 1.        ,  2.71828183,  7.3890561 , 20.08553692, 54.59815003])




```python
# Find the maximum value
a = np.random.random(10)
a[a.argmax()] = 0
a
```




    array([0.63151874, 0.24953231, 0.24048789, 0.04160484, 0.78822373,
           0.        , 0.12585763, 0.66083832, 0.22236498, 0.38146669])



# Useful NumPy Functions


```python
x = np.array([1, 2, 4, 7, 0], dtype=np.float32)
```


```python
# Referencing by indices
y = np.array([3, 3, 0])
x[y]
```




    array([7., 7., 1.], dtype=float32)




```python
# Trigonometric sine, element-wise.
np.sin(x)
```




    array([ 0.84147096,  0.9092974 , -0.7568025 ,  0.6569866 ,  0.        ],
          dtype=float32)




```python
# Calculate the n-th discrete difference along the given axis.
np.diff(x)
```




    array([ 1.,  2.,  3., -7.], dtype=float32)




```python
# Return the reciprocal of the argument, element-wise.
np.reciprocal(x)
```

    /home/manohar/anaconda3/lib/python3.7/site-packages/ipykernel_launcher.py:2: RuntimeWarning: divide by zero encountered in reciprocal
      





    array([1.        , 0.5       , 0.25      , 0.14285715,        inf],
          dtype=float32)




```python
np.power(x, y)
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-34-56b38dfee6de> in <module>
    ----> 1 np.power(x, y)
    

    ValueError: operands could not be broadcast together with shapes (5,) (3,) 


# Exercises

## Exercise 1) Convert the 1D array to a 2D array with 3x4 cells



```python
a = np.arange(12)
a
```


```python
a.reshape(3,4)
```

## Exercise 2) Replace odd numbers by -1


```python
arr = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
arr
```


```python
arr[1::2] = -1
arr
```


```python
a[a % 2 == 1] = -1
a
```

## Exercise 3) Retrieve positions where elements of a and b match


```python
a = np.array([1,2,3,2,3,4,3,4,5,6])
b = np.array([7,2,10,2,7,4,9,4,9,8])
```


```python
c=(a==b)
c
```


```python
i = np.arange(10)
i[a==b]
```


```python
# the hard way
[i for i, x in enumerate(a) if x==b[i]]
```

## Exercise 4) Drop all missing values from a numpy array


```python
a = np.array([1,2,3,np.nan,5,6,7,np.nan])
```


```python
b = np.isnan(a)
b
```


```python
a[~b]
```


```python
a[~np.isnan(a)]
```
